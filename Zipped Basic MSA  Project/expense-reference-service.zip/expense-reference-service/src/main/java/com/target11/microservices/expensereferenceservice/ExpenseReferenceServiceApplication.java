package com.target11.microservices.expensereferenceservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExpenseReferenceServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExpenseReferenceServiceApplication.class, args);
	}

}
