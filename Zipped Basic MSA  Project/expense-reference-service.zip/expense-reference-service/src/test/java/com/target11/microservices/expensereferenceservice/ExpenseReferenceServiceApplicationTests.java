package com.target11.microservices.expensereferenceservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenseReferenceServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
