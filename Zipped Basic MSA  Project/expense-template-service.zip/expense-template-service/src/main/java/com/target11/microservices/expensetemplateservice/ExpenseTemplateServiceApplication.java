package com.target11.microservices.expensetemplateservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExpenseTemplateServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExpenseTemplateServiceApplication.class, args);
	}

}
