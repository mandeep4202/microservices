package com.target11.microservices.expensetemplateservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenseTemplateServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
