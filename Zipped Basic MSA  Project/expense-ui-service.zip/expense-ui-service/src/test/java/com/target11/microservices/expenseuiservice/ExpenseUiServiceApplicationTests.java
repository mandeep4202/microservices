package com.target11.microservices.expenseuiservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenseUiServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
